module Tubuyaki
  VERSION = "0.0.4.2"
end
